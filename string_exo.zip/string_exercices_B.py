#B. both_ends

#Given a string s, return a string made of the first 2 and the last 2 chars of 
#the original string, so 'spring' yields 'spng'. However, if the string length 
#is less than 2, return instead the empty string.


def both_ends(s):
    result=""    
    if len(s)<=1:
        #print ""
        return ""
    else:
        #print s[:2]+s[-2:]   
        return s[:2]+s[-2:]

both_ends("shgwfjdhs")
both_ends("12")