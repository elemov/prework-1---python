# -*- coding: utf-8 -*-
"""
Created on Fri Sep 09 14:30:48 2016

@author: demo660
"""
#D. verbing
#Given a string, if its length is at least 3, add 'ing' to its end. Unless 
#it already ends in 'ing', in which case add 'ly' instead. If the string length 
#is less than 3, leave it unchanged. Return the resulting string.

def verbing(s):
    print s
    print s[:-3]
    print s[-3:]
    if len(s)<3:
        #print s
        return s
    else:
        if s[-3:]=="ing":
            print s[:-3]+"ly"            
            return s[:-3]+"ly"
        else:
            print s+"ing"
            return s+"ing"
    print s
    return s
verbing("g")
verbing("gd")
verbing("gdfhg")
verbing("hdgfsing")
verbing("swiminging")
