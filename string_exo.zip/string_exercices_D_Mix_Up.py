#D. MixUp

#Given strings a and b, return a single string with a and b separated by a 
#space '<a> <b>', except swap the first 2 chars of each string.

#e.g.
#'mix', pod' -> 'pox mid'

#'dog', 'dinner' -> 'dig donner'

#Assume a and b are length 2 or more.
def donuts(count):
    result=""
    string=""
    
    if count>=10:
        string="many"
    else:
        string=str(count)
    result="Number of donuts: "+string
    #print result
    return result

def both_ends(s):
    
    if len(s)<=1:
        #print ""
        return ""
    else:
        #print s[:2]+s[-2:]   
        return s[:2]+s[-2:]

def fix_start(s):
    if len(s)>=1:
        first_char=s[:1]
        #print first_char
        new_string=first_char
        
        for char in s[1:]:
            #print char
            if char==first_char:
                new_string+="*"
            elif char==first_char.upper():
                new_string+="*"
            elif char==first_char.lower():
                new_string+="*"
            else:
                new_string+=char
        #print new_string
        return new_string
    return ""

def mix_up(a, b):
    ch1=""
    ch2=""
    
    if len(a)>=2 and len(b)>=2:
        ch2=a[:2]
        #print ch2
        ch1=b[:2]
        #print ch1
        print ch1+a[2:]+" "+ch2+b[2:]
        return ch1+a[2:]+" "+ch2+b[2:]
    else:
        return ""
#Provided simple test() function used in main() to print what each function returns vs. what it's supposed to return.


def test(got, expected):
    prefix = 'OK' if got == expected else ' X'
    # !r prints a Python representation of the strings (complete with quotes)
    print ' {} got: {!r} expected: {!r}'.format(prefix, got, expected)


#Provided main() calls the above functions with interesting inputs, using test() 
#to check if each result is correct or not.


def main():
    print 'donuts'
    # Each line calls donuts, compares its result to the expected for that call.
    test(donuts(4), 'Number of donuts: 4')
    test(donuts(9), 'Number of donuts: 9')
    test(donuts(10), 'Number of donuts: many')
    test(donuts(99), 'Number of donuts: many')

    print
    print 'both_ends'
    test(both_ends('spring'), 'spng')
    test(both_ends('Hello'), 'Helo')
    test(both_ends('a'), '')
    test(both_ends('xyz'), 'xyyz')

  
    print
    print 'fix_start'
    test(fix_start('babble'), 'ba**le')
    test(fix_start('aardvark'), 'a*rdv*rk')
    test(fix_start('google'), 'goo*le')
    test(fix_start('donut'), 'donut')

    print
    print 'mix_up'
    test(mix_up('mix', 'pod'), 'pox mid')
    test(mix_up('dog', 'dinner'), 'dig donner')
    test(mix_up('gnash', 'sport'), 'spash gnort')
    test(mix_up('pezzy', 'firm'), 'fizzy perm')


#We call the main function.


main()

