# -*- coding: utf-8 -*-
"""
Created on Fri Sep 09 15:30:25 2016

@author: demo660
"""
#F. front_back
#Consider dividing a string into two halves. If the length is even, the front 
#and back halves are the same length. If the length is odd, we'll say that the 
#extra char goes in the front half.

#e.g. 'abcde', the front half is 'abc', the back half 'de'.

#Given 2 strings, a and b, return a string of the form a-front + b-front + a-back + b-back
def test(got, expected):
    prefix = 'OK' if got == expected else ' X'
    # !r prints a Python representation of the strings (complete with quotes)
    print ' {} got: {!r} expected: {!r}'.format(prefix, got, expected)

def not_bad(s):
    key1="not"
    key2="bad"
    before_key1=""
    after_key1=""
    before_key2=""
    after_key2=""
    
    if key1 in s:
        before_key1,key1,after_key1=s.partition(key1)
        if key2 in after_key1:
            before_key2,key2,after_key2=s.partition(key2)
            print before_key1+"good"+after_key2
            return before_key1+"good"+after_key2
       
            
    # +++your code here+++
    print s    
    return s 
    
def verbing(s):
    #print s
    #print s[:-3]
    #print s[-3:]
    if len(s)<3:
        #print s
        return s
    else:
        if s[-3:]=="ing":
            #print s[:-3]+"ly"            
            return s[:-3]+"ly"
        else:
            #print s+"ing"
            return s+"ing"
    #print s
    return s


def front_back(a, b):
    length_a=len(a)
    length_b=len(b)
    
    print length_a
    print length_b
    
    if length_a%2==0:
        
        a_front=a[:length_a/2]
        a_back=a[length_a/2:]
    else:
         a_front=a[:int(length_a/2)+1]
         a_back=a[int(length_a/2)+1:]
    if length_b%2==0:
        
        b_front=b[:length_b/2]
        b_back=b[length_b/2:]
    else:
         b_front=b[:int(length_b/2)+1]
         b_back=b[int(length_b/2)+1:]
    
    print a_front+b_front+a_back+b_back
    return a_front+b_front+a_back+b_back


def main():
    print 'verbing'
    test(verbing('hail'), 'hailing')
    test(verbing('swiming'), 'swimingly')
    test(verbing('do'), 'do')
    
    print
    print 'not_bad'
    test(not_bad('This movie is not so bad'), 'This movie is good')
    test(not_bad('This dinner is not that bad!'), 'This dinner is good!')
    test(not_bad('This tea is not hot'), 'This tea is not hot')
    test(not_bad("It's bad yet not"), "It's bad yet not")

    print
    print 'front_back'
    test(front_back('abcd', 'xy'), 'abxcdy')
    test(front_back('abcde', 'xyz'), 'abcxydez')
    test(front_back('Kitten', 'Donut'), 'KitDontenut')



#We call the main function.


main()

