# -*- coding: utf-8 -*-
"""
Created on Fri Sep 09 15:03:14 2016

@author: demo660
"""
#E. not_bad

#Given a string, find the first appearance of the substring 'not' and 'bad'. 
#If the 'bad' follows the 'not', replace the whole 'not'...'bad' substring with 'good'.

#Return the resulting string.

#So 'This dinner is not that bad!' yields: This dinner is good!



def not_bad(s):
    key1="not"
    key2="bad"
    before_key1=""
    after_key1=""
    before_key2=""
    after_key2=""
    
    if key1 in s:
        before_key1,key1,after_key1=s.partition(key1)
        if key2 in after_key1:
            before_key2,key2,after_key2=s.partition(key2)
            print before_key1+"good"+after_key2
            return before_key1+"good"+after_key2
       
            
    # +++your code here+++
    print s    
    return s 

not_bad("This dinner is not that bad!")
not_bad("This dinner is bad!")
not_bad("This movie is not so bad")
not_bad("This dinner is not that bad!")
not_bad("This tea is not hot")
not_bad("It's bad yet not")