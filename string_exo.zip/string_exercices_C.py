#C. fix_start

#Given a string s, return a string where all occurences of its first char have 
#been changed to '*', except do not change the first char itself.

#e.g. 'babble' yields 'ba**le'

#Assume that the string is length 1 or more. Hint: s.replace(stra, strb) 
#returns a version of string s where all instances of stra have been replaced by strb.

def fix_start(s):
    if len(s)>=1:
        first_char=s[:1]
        #print first_char
        new_string=first_char
        
        for char in s[1:]:
            #print char
            if char==first_char:
                new_string+="*"
            elif char==first_char.upper():
                new_string+="*"
            elif char==first_char.lower():
                new_string+="*"
            else:
                new_string+=char
        #print new_string
        return new_string
    return ""

fix_start("SjhgjssvSgf")
fix_start("sjhgjssvSgf")
fix_start("S")
fix_start("")