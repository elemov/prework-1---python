#D. remove_adjacent

#Given a list of numbers, return a list where all adjacent == elements have 
#been reduced to a single element, so [1, 2, 2, 3] returns [1, 2, 3]. 
#You may create a new list or modify the passed in list.
t = [1, 2, 3, 1, 2, 5, 6, 7, 8]
print t
def remove_adjacent(nums):
    result=[]
    result=list(set(nums))
    print result
    return result

remove_adjacent(t)