#B. front_x

#Given a list of strings, return a list with the strings in sorted order, 
#except group all the strings that begin with 'x' first.

#e.g. ['mix', 'xyz', 'apple', 'xanadu', 'aardvark'] yields ['xanadu', 'xyz', 'aardvark', 'apple', 'mix']

#Hint: this can be done by making 2 lists and sorting each of them before combining them.
import numpy as np

n=["ada","h","abracadabra","bling", "baobab","hh","xyz", "brouhaha","Xolly"]
def front_x(words):
    x=[]
    a=[]
    result=[]
    for item in words:
        if item[:1]=="x":
            x.append(item)
        elif item[:1]=="X":
             x.append(item)
        else:
            a.append(item)
    print x
    print a 
    x.sort()
    a.sort()
    print x
    print a
    result=np.concatenate([x,a])
    #result=x+a
    print result
    return result
front_x(n)
