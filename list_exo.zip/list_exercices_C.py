#C. sort_last

#Given a list of non-empty tuples, return a list sorted in increasing order by 
#the last element in each tuple.

#e.g. [(1, 7), (1, 3), (3, 4, 5), (2, 2)] yields [(2, 2), (1, 3), (3, 4, 5), (1, 7)]

#Hint: use a custom key= function to extract the last element form each tuple.
def match_ends(words):
    
    a=[]
    b=[]
   # i=0
    for item in words:
        if len(item)>=2:
            a.append(item[:1])
            b.append(item[-1:])
            
            result=0
            for i in range(len(a)):
                if a[i]==b[i]:
                    result+=1
                    print result
    print a
    print b    
    print result
    
    return result
    
def front_x(words):
    x=[]
    a=[]
    result=[]
    for item in words:
        if item[:1]=="x":
            x.append(item)
        elif item[:1]=="X":
             x.append(item)
        else:
            a.append(item)
    print x
    print a 
    x.sort()
    a.sort()
    print x
    print a
    result=x+a
    print result
    return result

def getKey(item):
    return item[-1:]
    
def sort_last(tuples):
    result=[]
    result=sorted(tuples,key=getKey)
   
    return result

#Simple provided test() function used in main() to print what each function 
#returns vs. what it's supposed to return.



def test(got, expected):
    prefix = 'OK' if got == expected else ' X'
    # !r prints a Python representation of the strings (complete with quotes)
    print ' {} got: {!r} expected: {!r}'.format(prefix, got, expected)

#Calls the above functions with interesting inputs.


def main():
    print 'match_ends'
    test(match_ends(['aba', 'xyz', 'aa', 'x', 'bbb']), 3)
    test(match_ends(['', 'x', 'xy', 'xyx', 'xx']), 2)
    test(match_ends(['aaa', 'be', 'abc', 'hello']), 1)

    print
    print 'front_x'
    test(front_x(['bbb', 'ccc', 'axx', 'xzz', 'xaa']),
        ['xaa', 'xzz', 'axx', 'bbb', 'ccc'])
    test(front_x(['ccc', 'bbb', 'aaa', 'xcc', 'xaa']),
        ['xaa', 'xcc', 'aaa', 'bbb', 'ccc'])
    test(front_x(['mix', 'xyz', 'apple', 'xanadu', 'aardvark']),
        ['xanadu', 'xyz', 'aardvark', 'apple', 'mix'])
    
    print
    print 'sort_last'
    test(sort_last([(1, 3), (3, 2), (2, 1)]),
         [(2, 1), (3, 2), (1, 3)])
    test(sort_last([(2, 3), (1, 2), (3, 1)]),
         [(3, 1), (1, 2), (2, 3)])
    test(sort_last([(1, 7), (1, 3), (3, 4, 5), (2, 2)]),
         [(2, 2), (1, 3), (3, 4, 5), (1, 7)])


#We call the main function.


main()

