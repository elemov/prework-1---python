#A. match_ends

#Given a list of strings, return the count of the number of strings where the 
#string length is 2 or more and the first and last chars of the string are the same.

#Note: python does not have a ++ operator, but += works.
n=["ada","h","abracadabra","bling", "baobab","hh"]

def match_ends(words):
    
    a=[]
    b=[]
   # i=0
    for item in words:
        if len(item)>=2:
            a.append(item[:1])
            b.append(item[-1:])
            
            result=0
            for i in range(len(a)):
                if a[i]==b[i]:
                    result+=1
                    print result
    print a
    print b    
    print result
    
    return result
 
match_ends(n)   

