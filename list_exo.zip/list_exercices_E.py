#E. linear_merge

#Given two lists sorted in increasing order, create and return a merged list 
#of all the elements in sorted order. You may modify the passed in lists. 
#Ideally, the solution should work in "linear" time, making a single pass of both lists.
def test(got, expected):
    prefix = 'OK' if got == expected else ' X'
    # !r prints a Python representation of the strings (complete with quotes)
    print ' {} got: {!r} expected: {!r}'.format(prefix, got, expected)

def remove_adjacent(nums):
    result=[]
    result=list(set(nums))
    print result
    return result
    
def linear_merge(list1, list2):
    list1.extend(list2)
    return sorted(list1)

#Calls the above functions with interesting inputs.

def main():
    print 'remove_adjacent'
    test(remove_adjacent([1, 2, 2, 3]), [1, 2, 3])
    test(remove_adjacent([2, 2, 3, 3, 3]), [2, 3])
    test(remove_adjacent([]), [])

    print
    print 'linear_merge'
    test(linear_merge(['aa', 'xx', 'zz'], ['bb', 'cc']),
        ['aa', 'bb', 'cc', 'xx', 'zz'])
    test(linear_merge(['aa', 'xx'], ['bb', 'cc', 'zz']),
        ['aa', 'bb', 'cc', 'xx', 'zz'])
    test(linear_merge(['aa', 'aa'], ['aa', 'bb', 'bb']),
        ['aa', 'aa', 'aa', 'bb', 'bb'])


#We call the main function.


main()

